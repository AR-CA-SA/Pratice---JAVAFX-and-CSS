package com.example.guicoffeshop;

public class mug extends Product {
    public mug(String name, double price) {
        super(name, price);
    }
}

